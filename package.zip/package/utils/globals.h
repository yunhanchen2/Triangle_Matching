#ifndef UTILS_GLOBALS
#define UTILS_GLOBALS

#include <atomic>

using namespace  std;

extern std::atomic<bool> reach_time_limit;

#endif //UTILS_GLOBALS
