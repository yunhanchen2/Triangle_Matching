#include "globals.h"

std::atomic<bool> reach_time_limit(false);