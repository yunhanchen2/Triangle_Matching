
#include <fstream>
#include <tuple>
#include "../utils/types.h"
#include "graph.h"

using namespace std;

int main(){
    Graph G;

    const string m="../../G1.txt";

    G.LoadFromFile(m);

    G.PrintMetaData();

    return 0;
}